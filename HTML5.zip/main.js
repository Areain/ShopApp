

document.addEventListener('DOMContentLoaded', function () {
    let products = JSON.parse(localStorage.getItem('products')) || [];

    const searchPage = document.getElementById('searchPage');
    const customizePage = document.getElementById('customizePage');
    const searchInput = document.getElementById('searchInput');
    const results = document.getElementById('results');
    const editResults = document.getElementById('editResults');
    const addProductForm = document.getElementById('addProductForm');

    function renderProducts(productsToRender, targetElement, includeEdit = false) {
        targetElement.innerHTML = '';
        productsToRender.forEach(product => {
            const productElement = document.createElement('div');
            productElement.classList.add('product');
            productElement.innerHTML = `
                <div class="product-container">
                    <div class="product-images"></div>
                    <div class="product-details">
                        <div class="product-name">${product.name}</div>
                        <div class="product-category">${product.category}</div>
                        <div class="product-price">${product.price}</div>
                    </div>
                </div>
            `;
            const productImagesContainer = productElement.querySelector('.product-images');
            if (product.images) {
                product.images.forEach(imageUrl => {
                    const img = document.createElement('img');
                    img.src = imageUrl;
                    img.classList.add('product-image');
                    productImagesContainer.appendChild(img);
                });
            }
            if (includeEdit) {
                const editButton = document.createElement('button');
                editButton.textContent = 'Edit';
                editButton.classList.add('edit-button');
                editButton.setAttribute('data-id', product.id);
                productElement.appendChild(editButton);
                
                const removeButton = document.createElement('button');
                removeButton.textContent = 'Remove';
                removeButton.classList.add('remove-button');
                removeButton.setAttribute('data-id', product.id);
                productElement.appendChild(removeButton);
            }
            targetElement.appendChild(productElement);
        });

        if (includeEdit) {
            const removeButtons = targetElement.querySelectorAll('.remove-button');
            removeButtons.forEach(button => {
                button.addEventListener('click', function () {
                    const productId = this.dataset.id;
                    products = products.filter(product => product.id !== productId);
                    localStorage.setItem('products', JSON.stringify(products));
                    renderProducts(products, editResults, true);
                });
            });
            
            const editButtons = targetElement.querySelectorAll('.edit-button');
            editButtons.forEach(button => {
                button.addEventListener('click', function () {
                    const productId = this.dataset.id;
                    const product = products.find(p => p.id == productId);
                    if (product) {
                        document.getElementById('addProductName').value = product.name;
                        document.getElementById('addProductCategory').value = product.category;
                        document.getElementById('addProductPrice').value = product.price;
                        addProductForm.dataset.editing = productId;
                    }
                });
            });
        }
    }

    function showPage(page) {
        searchPage.classList.add('hidden');
        customizePage.classList.add('hidden');
        document.getElementById(page).classList.remove('hidden');
    }

    searchInput.addEventListener('input', function () {
        const query = searchInput.value.toLowerCase();
        if (query) {
            const filteredProducts = products.filter(product => product.name.toLowerCase().includes(query));
            renderProducts(filteredProducts, results); // No edit button on search results
        } else {
            results.innerHTML = ''; // Clear results if search input is empty
        }
    });

    addProductForm.addEventListener('submit', function (event) {
        event.preventDefault();
        const name = document.getElementById('addProductName').value;
        const category = document.getElementById('addProductCategory').value;
        const price = document.getElementById('addProductPrice').value;
        const images = [];
        const imageFiles = document.getElementById('addProductImage').files;
        for (let i = 0; i < imageFiles.length; i++) {
            images.push(URL.createObjectURL(imageFiles[i]));
        }
        const editingId = addProductForm.dataset.editing;

        if (editingId) {
            const productIndex = products.findIndex(p => p.id == editingId);
            if (productIndex >= 0) {
                products[productIndex] = { id: editingId, name, category, price, images };
                addProductForm.removeAttribute('data-editing');
            }
        } else {
            const id = Date.now();
            products.push({ id, name, category, price, images });
        }

        localStorage.setItem('products', JSON.stringify(products));
        addProductForm.reset();
        renderProducts(products, editResults, true); // Edit button included here
    });

    document.getElementById('goToCustomizePage').addEventListener('click', function () {
        showPage('customizePage');
        renderProducts(products, editResults, true); // Render products with edit option on customize page
    });

    document.getElementById('backToSearchPage').addEventListener('click', function () {
        showPage('searchPage');
    });

    document.getElementById('showInventory').addEventListener('click', function () {
        renderProducts(products, results);
    });
});